<!doctype html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Transport System</title>
        <link rel="stylesheet" type="text/css"  href="hacka.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Lora:ital@1&display=swap" rel="stylesheet">
<!-- <script type="text/javascript">
    function driver_click() {
    
    }
    </script> -->
    </head>
    <body>
        <div class="container">
        <h1 style="color:white; font-family: 'Dancing Script', cursive;
        font-family: 'Lora', serif;  position: absolute; top: 8px; left: 16px; font-size: 30px;">Transport System</h1>
    
        <img src="i1.jpg" alt="backgroung image">
        
        
        <button class="btn" onClick="parent.open('register_driver.php')"> DRIVER</button>
       

        
        <button class="btn2" onClick="parent.open('register.php')"> DEALER</button> 
            
        </div>
        
        


    </body>
</html>



