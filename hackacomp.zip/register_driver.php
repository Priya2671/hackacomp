<?php
require_once('config.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title> USER REGISTRATION | PHP</title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
</head>
<body>
<div>
<?php  
    if(isset($_POST['create'])){
       $Name              = $_POST['Name'];    
       $Age               = $_POST['Age'];  
       $TruckNumber       = $_POST['TruckNumber'];  
       $MobileNumber      = $_POST['MobileNumber'];  
       $TruckCapacity     = $_POST['TruckCapacity'];  
       $TransporterName   = $_POST['TransporterName'];
       $Routes            = $_POST['Routes'];
       $DrivingExperience = $_POST['DrivingExperience'];
       $EmailID           = $_POST['EmailID'];
       $Password          = $_POST['Password'];
           $sql = "INSERT INTO register_driver( Name,Age,TruckNumber,MobileNumber,TruckCapacity,TransporterName,Routes,DrivingExperience,EmailID,Password) VALUES(?,?,?,?,?,?,?,?,?,?)";
           $stmtinsert = $db->prepare($sql);
           $Password = password_hash($Password, PASSWORD_BCRYPT);
           $result = $stmtinsert->execute([$Name,$Age,$TruckNumber,$MobileNumber,$TruckCapacity,$TransporterName,$Routes,$DrivingExperience,$EmailID,$Password]);
           if($result){
               echo 'Successfully saved.';
           }else{
               echo 'There were errors while saving the data.';
           }
    }
?>
</div>
    
    
<div>
    <form action="register_driver.php" method="post">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                <h1> Driver-Registration </h1>
                <p>Fill up the form with correct values.</p>

                <label for="Name"><b> Name</b></label>
                <input class="form-control"  type="text" name="Name" required> 

                <label for="Age"><b>Age</b></label>
                <input class="form-control" type="text" name="Age" required> 

                <label for="TruckNumber"><b>TruckNumber</b></label>
                <input class="form-control" type="text" name="TruckNumber" required> 

                <label for="MobileNumber"><b>MobileNumber</b></label>
                <input class="form-control"type="text" name="MobileNumber" required> 

                <label for="TruckCapacity"><b>TruckCapacity</b></label>
                <input class="form-control" type="text" name="TruckCapacity" required>

                <label for="TransporterName"><b>TransporterName</b></label>
                <input class="form-control" type="text" name="TransporterName" required> 

                <label for="Routes"><b>Routes</b></label>
                <input class="form-control" type="text" name="Routes" required>

                <label for="DrivingExperience"><b>DrivingExperience</b></label>
                <input class="form-control" type="text" name="DrivingExperience" required> 

                <label for="EmailID"><b>EmailID</b></label>
                <input class="form-control" type="text" name="EmailID" required> 

                <label for="Password"><b>Password</b></label>
                <input class="form-control" type="text" name="Password" required> 
                <hr class="mb-3">
                <input class="btn btn-primary" type="submit" id="register" name="create" value="sign up">
                </div>
            </div>
        </div>
    </form>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script type="text/javascript">
        $(function(){
            $('#register').click(function(e){
                Swal.fire({
                'title':'successful',
                'text' :'successfully Registered!!',
                'type':'Success'
                })
            });
        });
    
</script>
</body>
</html>

